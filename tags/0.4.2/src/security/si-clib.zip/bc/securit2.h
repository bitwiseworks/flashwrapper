/*************************************************
  SecureIt for OS/2 v2.0
  Borland C++ interface definition
  (C) 1997 Allan Mertner
*************************************************/

#include <os2.h>

/* Constants returned by KeyQuerySerialNumberStatus API */

#define snUndefined 0
#define snValid     1
#define snLocked    2
#define snExpired   3


#ifdef __cplusplus
  extern "C" {
#endif


/* SecureIt v2 API definitions */

VOID _cdecl KeySetNamePsw(PCHAR Name, PCHAR Psw);
  /* Specify name and password as entered by user, C style */

BOOL _cdecl KeySetNamePswIni(PCHAR FileName, PCHAR AppName);
  /* Read Name and Password from INI file */

BOOL _cdecl KeyWriteNamePswToIni(PCHAR FileName, PCHAR AppName);
  /* Write a good Name and Password to INI file */

ULONG _cdecl KeyGetRegisteredName(PCHAR Buffer, ULONG BufLen);
  /* Returns the registered name in Buffer of length BufLen */


VOID _cdecl KeySetVersion(ULONG Version);
  /* Set version number (obsolete) */

VOID _cdecl KeySetup(BOOL UseSerialNo, BOOL UseHighAscii, BOOL UseRSAPassword,
     LONG Version, PVOID ExtraData, LONG ExtraLen);
  /* 2.0: Setup up SecureIt version code, Serial Number, Blob data */

VOID _cdecl KeySetCallOffsets(ULONG High, PLONG Offsets);
  /* 2.0: Define offsets for all CallBack fields in password */

VOID _cdecl KeySetPatchOffsets(ULONG High, PLONG Offsets);
  /* 2.0: Define offsets for all CodePatch fields in password */


BOOL _cdecl KeyCheck(BOOL Automatic);
  /* Check if name/password combination is valid; if Automatic */
  /* is True, performs all Patches and Calls automatically */

BOOL _cdecl KeyDispatch(ULONG Number);
  /* Manually call function specified in Number (1-4) */

BOOL _cdecl KeyCodePatch(ULONG Number);
  /* Manually patch code specified in Number (1-4) */

ULONG _cdecl KeyQueryUserValue(ULONG Number);
  /* Retrieve user value specified in Number (1-4) */


ULONG _cdecl KeyGetSerialNumber(VOID);
  /* 2.0: Return the current serial number; -1 if error or undefined */

BYTE _cdecl KeyGetSerialNumberStatus(VOID);
  /* 2.0: Return the serial number status */

BOOL _cdecl KeyGetSerialNumberExpiry(PULONG Year, PULONG Month, PULONG Day);
  /* 2.0: Return the date of expiry for the current serial number; FALSE if no expiry */


ULONG _cdecl KeyGetUserString(ULONG Index, PCHAR Buffer, ULONG BufLen);
  /* 2.0: Return decoded string Index from data blob */

ULONG _cdecl KeyGetFileChecksum(PCHAR FileName, LONG CheckLen);
  /* 2.0: Calculate 32-bit CRC of file */

ULONG _cdecl KeyGetCRC32(PCHAR Data, LONG Len);
  /* 2.0: Calculate 32-bit CRC of block of data */

BOOL _cdecl KeyManualPatch(ULONG Address, ULONG Size, VOID * Data);
  /* Manually patch code at Address with Data^, for Size bytes */

BOOL _cdecl KeyManualDispatch(ULONG Address);
  /* Manually call the code at Address */

VOID _cdecl KeyManualJump(ULONG Address);
  /* Transfer control, Jump, to Address */

VOID _cdecl KeyOverwriteCode(ULONG From, ULONG WithData);
  /* Overwrite code from address From with data Withdata, until return address */

VOID _cdecl KeyScrambleStr(PCHAR S, ULONG Seed);
  /* Scramble C style string */

VOID _cdecl KeyAllowDebugger(VOID);
  /* Allow the SecureIt code to be debugged */


#ifdef __cplusplus
  }
#endif

